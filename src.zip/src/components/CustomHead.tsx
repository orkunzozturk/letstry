// Override this file to include custom code in the <head>
import React from 'react';
import { Helmet } from 'react-helmet';

export const CustomHead = () => (
  <Helmet>{
    }</Helmet>
);
