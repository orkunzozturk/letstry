export type Category = {
  slug: string;
  name: string;
  url: string;
  description: string;
  image: string;
  status: string;
};
