export type Mdx<T, F> = {
  body: any;
  frontmatter: T;
  fields: F;
};
